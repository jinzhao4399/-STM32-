#include "widget.h"
#include "form.h"
#include <QApplication>
#include <QtMqtt/qmqttclient.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //定义一个窗体
    Widget w;
    //显示窗体
    w.show();
    return a.exec();
}
