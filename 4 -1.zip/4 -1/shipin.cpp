#include "shipin.h"
#include "ui_shipin.h"

shipin::shipin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::shipin)
{
    v=new fsmpCamera;
        v->setPixDelay(40);
        v->start();
        connect(v,SIGNAL(pixReady(QImage)),this,SLOT(show_pic(QImage)));
}

shipin::~shipin()
{
    delete ui;
}

void shipin::on_pushButton_clicked()
{
            if (ui->label && !pic.isNull()) {
                // 获取label的可用显示区域大小
                QSize labelSize = ui->label->size();

                // 将QImage转换为QPixmap并进行缩放（保持宽高比）
                QPixmap pixmap = QPixmap::fromImage(pic);
                pixmap = pixmap.scaled(labelSize,
                                      Qt::KeepAspectRatio,
                                      Qt::SmoothTransformation);

                // 设置pixmap并居中显示
                ui->label->setPixmap(pixmap);
                ui->label->setAlignment(Qt::AlignCenter);


            }
              }

