#include "widget.h"
#include "ui_widget.h"
#include <QMessageBox>  // 添加弹窗类头文件
#include "form.h"  // 添加主界面头文件
#include <QLCDNumber>
#include "shipin.h"
#include <QtMqtt/qmqttclient.h>


Widget::Widget(QWidget *parent)  //构造函数这里关联
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    //主动实现信号与槽的关联
    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(Widget::on_pushButton_clicked));
    //显示图片
    //1.创建图片对象
    QPixmap image;
    //2.将需要使用的图片加载到对象中
    image.load(":/1.jpg");//"."表示当前目录
    //将图片按照比例进行缩放
    ui->label_3->setScaledContents("ture");
    //在标签上显示图片
    ui->label_3->setPixmap(image);
}

Widget::~Widget()
{
    delete ui;
}

//用户自定义槽函数
void Widget::on_pushButton_clicked(){
     QString str=ui->lineEdit_2->text();
     QString str1=ui->lineEdit->text();
     if(str!="once"||str1!="4399"){
         QMessageBox::warning(this, "错误", "请重新输入密码！");
         ui->lineEdit->clear();
         ui->lineEdit_2->clear();
         return;
     }
     else{
         QMessageBox::warning(this, "正确", "即将进入主界面！");
         //定义一个窗体
         Form *m;//加*号，是为了创建对象指针，指针用于堆区
         m= new Form ;//给对象指针在堆区开辟空间
         //显示窗体
         m->show();

         this->close();//关闭当前窗口   this表示当前窗口对象指针
        // this->hide();//隐藏窗口,两者二选一
     }
}
