#ifndef SHIPIN_H
#define SHIPIN_H
#include "fsmpCamera.h"
#include <QWidget>

namespace Ui {
class shipin;
}

class shipin : public QWidget
{
    Q_OBJECT

public:
    explicit shipin(QWidget *parent = nullptr);
    ~shipin();

private slots:
    void on_pushButton_clicked();
     void show_pic(const QImage& pic);

private:
    Ui::shipin *ui;
    fsmpCamera *v;
};

#endif // SHIPIN_H
