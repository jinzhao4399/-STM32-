#ifndef CONNECT_H
#define CONNECT_H

#include <QWidget>
#include <QtMqtt/qmqttclient.h>

namespace Ui {
class connect;
}

class connect : public QWidget
{
    Q_OBJECT

public:
    explicit connect(QWidget *parent = nullptr);
    ~connect();
private slots:
    void link();

private:
    Ui::connect *ui;
    QMqttClient *client;
};

#endif // CONNECT_H
