#include "connect.h"
#include "ui_connect.h"
#include <QtMqtt/qmqttclient.h>
#include <QMessageBox>

connect::connect(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::connect)
{
    ui->setupUi(this);
    QPixmap image;
    image.load(":/2.jpg");
    ui->label->setScaledContents(true);
    ui->label->setPixmap(image);
}

connect::~connect()
{
    delete ui;
}



