﻿#include "form.h"
#include "ui_form.h"
#include <QLCDNumber>
#include "shipin.h"
#include <QtMqtt/qmqttclient.h>
#include <QMessageBox>  // 添加弹窗类头文件
#include <QTimer>



Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
      , v(nullptr)
{
    ui->setupUi(this);
    led1=new fsmpLeds;
    fan=new fsmpFan;
    beeper=new fsmpBeeper;
    vibrator=new fsmpVibrator;
    light=new fsmpLight;
    tem=new fsmpTempHum;
    m_publishTopic = "WENXUAN4399";
    m_subscribeTopic = "4399WENXUAN";

    v=new fsmpCamera("/dev/video1");
      client=new QMqttClient;
      connect(client,SIGNAL(connected()),this,SLOT(link()));
      connect(client,SIGNAL(messageReceived(QByteArray,QMqttTopicName)),this,SLOT(recv_data(QByteArray,QMqttTopicName)));

      // 温湿度定时器初始化
      tempHumTimer = new QTimer(this);
      connect(tempHumTimer, SIGNAL(timeout()), this, SLOT(updateTempHumValue()));
      tempHumTimer->start(2000);  // 每2秒更新一次

      // 初始化显示
      updateTempHumValue();
      // 初始化光强定时器
      lightTimer = new QTimer(this);
      connect(lightTimer, SIGNAL(timeout()), this, SLOT(updateLightValue()));
      lightTimer->start(1000); // 每1秒更新一次
}

Form::~Form()
{
    if (v!= nullptr) {
                delete v;
                v = nullptr;
            }
    delete ui;
}

// 在form.cpp中，修改updateLightValue的实现
void Form::updateLightValue()
{
    if (light) {
        double lightValue = light->getValue();
        // 将光强值显示在QLineEdit中
        ui->lineEdit_8->setText(QString::number(lightValue, 'f', 2) + " lux");
        if (lightValue > 500.0) {
                    // 检查遮阳板是否已经关闭（通过按钮文本来判断）
                    if (ui->pushButton_7->text() == "遮阳板") {
                        // 发送打开遮阳板的MQTT消息
                        QByteArray msg = "{\"sunshade\":\"forward\",\"id\":0}";
                        client->publish(ui->lineEdit_12->text(), msg);

                        // 更新按钮文本
                        ui->pushButton_7->setText("关闭");
        }
    }
    }
}


// 温湿度更新函数
void Form::updateTempHumValue()
{
    if (tem) {
        // 获取温湿度值
        double temperature = tem->temperature();
        double humidity = tem->humidity();

        // 显示温湿度（假设有两个QLineEdit控件）
        if (ui->lineEdit_4) {
            ui->lineEdit_4->setText(QString::number(temperature, 'f', 1) + " °C");
        }

        if (ui->lineEdit_5) {
            ui->lineEdit_5->setText(QString::number(humidity, 'f', 1) + " %");
        }
    }
}

void Form::show_pic(QImage pic) {
    QPixmap pixmap = QPixmap::fromImage(pic);
    ui->label_2->setScaledContents(true);
    ui->label_2->setPixmap(pixmap);
}

void Form::on_pushButton_10_clicked()
{
    v = new fsmpCamera("/dev/video1");
    connect(v, SIGNAL(pixReady(QImage)), this, SLOT(show_pic(QImage)));
    v->setPixDelay(40);
    v->start();
}

void Form::on_pushButton_2_clicked() {
    if(ui->pushButton_2->text() == "喷淋"){
      QByteArray msg="{\"irrigated\":true,\"id\":0}";
      client->publish(ui->lineEdit_12->text(),msg);
      ui->pushButton_2->setText("触发");
    }
    else if(ui->pushButton_2->text() == "触发"){
       QByteArray msg="{\"irrigated\":false,\"id\":0}";
       client->publish(ui->lineEdit_12->text(),msg);
       ui->pushButton_2->setText("喷淋");
    }
}


void Form::on_pushButton_clicked()
{
    client->setHostname("mqtt.yyzlab.com.cn");
    client->setPort(1883);
    client->connectToHost();//连接服务器    connect *b;

}


void Form::link()
{
    QMessageBox::about(NULL,"提示","连接成功！");
    QMqttTopicFilter topic=m_subscribeTopic;
    client->subscribe(topic);
   // client->subscribe(ui->lineEdit_5->text());
    connect(client,SIGNAL(messageReceived(QByteArray,QMqttTopicName)),this,SLOT(recv_data(QByteArray,QMqttTopicName)));
}

void Form::on_pushButton_3_clicked()
{
    if(ui->pushButton_3->text() == "打开风扇"){
           fan->setSpeed(200);
           fan->start();
      ui->pushButton_3->setText("关闭风扇");
      QByteArray msg="{\"fan\":true,\"id\":0}";
      client->publish(ui->lineEdit_12->text(),msg);

    }
    else if(ui->pushButton_3->text() == "关闭风扇"){
        fan->stop();
        ui->pushButton_3->setText("打开风扇");
        QByteArray msg="{\"fan\":false,\"id\":0}";
        client->publish(ui->lineEdit_12->text(),msg);
    }
}

void Form::on_pushButton_7_clicked()
{
    if(ui->pushButton_7->text()=="遮阳板"){
    QByteArray msg="{\"sunshade\":\"forward\",\"id\":0}";
    client->publish(ui->lineEdit_12->text(),msg);
    ui->pushButton_7->setText("关闭");
}
    else{
        QByteArray msg="{\"sunshade\":\"stop\",\"id\":0}";
        client->publish(ui->lineEdit_12->text(),msg);
        ui->pushButton_7->setText("遮阳板");
    }
}


void Form::on_pushButton_9_clicked()
{
    if(ui->pushButton_9->text() == "一键打开"){
        //开灯
        led1->on(fsmpLeds::LED1);
        led1->on(fsmpLeds::LED2);
      QByteArray msg="{\"lamp\":true,\"id\":0}";
      client->publish(ui->lineEdit_12->text(),msg);
      ui->pushButton_9->setText("一键关闭");
    }
    else if(ui->pushButton_9->text() == "一键关闭"){
            //关灯
            led1->off(fsmpLeds::LED1);
            led1->off(fsmpLeds::LED2);
       QByteArray msg="{\"lamp\":false,\"id\":0}";
       client->publish(ui->lineEdit_12->text(),msg);
       ui->pushButton_9->setText("一键打开");
    }
}

void Form::on_pushButton_4_clicked()
{
    if(ui->pushButton_4->text() == "警报"){
        beeper->setRate(1000);     //设置频率
        beeper->start();
      ui->pushButton_4->setText("关闭");
    }
    else if(ui->pushButton_4->text() == "关闭"){
            //关灯
        beeper->stop();
       ui->pushButton_4->setText("警报");
    }
}

void Form::on_pushButton_8_clicked()
{
    if(ui->pushButton_8->text() == "开门"){
      QByteArray msg="{\"doorLock\":true,\"id\":0}";
      client->publish(ui->lineEdit_12->text(),msg);
      ui->pushButton_8->setText("关门");
      vibrator->setParameter(0xFFFF, 3000); // 强度最大，持续3秒
      vibrator->start();
    }
    else if(ui->pushButton_8->text() == "关门"){
       QByteArray msg="{\"doorLock\":false,\"id\":0}";
       client->publish(ui->lineEdit_12->text(),msg);
       ui->pushButton_8->setText("开门");
       vibrator->setParameter(0x8000, 1000); // 中等强度，持续1秒
       vibrator->start();
    }
}

void Form::recv_data(QByteArray buf,QMqttTopicName)//buf中的信息为json格式：{“lamp”:}
{
    //判断buf属于哪一个设备的信息
    QString arr=QString(buf).mid(2,3);//mid表示截取字符串,因为key的名字不一样，从第二位开始截取字符，用来区别每一个设备
        if(arr=="co2"){
        //解析josn格式数据
        QJsonDocument jdoc= QJsonDocument::fromJson(buf);//转换为json格式数据
        QJsonObject jobj=jdoc.object();//将数据转换为josn数据对象
        QJsonValue jval=jobj.value("co2");//在内输入对应的key，即可检索到对应的value

        double my_co2=jval.toDouble();
        ui->lineEdit_7->setText(QString::number(my_co2));
        if (my_co2>=251.2)
        {
            fan->setSpeed(200);
            fan->start();
        }
        else
        {
            fan->stop();
                 }
        }
        else if(arr=="PM2")
        {
            QJsonDocument jdoc = QJsonDocument::fromJson(buf);   //转换为Json格式数据
            QJsonObject jobj = jdoc.object();               //将数据转换为Json格式对象
            QJsonValue jval = jobj.value("PM2.5");

           double my_PM2 = jval.toDouble();

            ui->lineEdit_6->setText(QString::number(my_PM2));
            if (my_PM2>=700)
            {
                QMessageBox::about(NULL,"提示","PM已超标，请注意防护！");
            }
            else{};
        }
        else if(arr == "smog"){
            QJsonDocument jdoc = QJsonDocument::fromJson(buf);   //转换为Json格式数据
            QJsonObject jobj = jdoc.object();               //将数据转换为Json格式对象
            QJsonValue jval = jobj.value("smog");

           double my_smog = jval.toDouble();

                    double threshold = 20.0;
                    if (my_smog > threshold) {
                        QByteArray msg="{\"smog\":true,\"id\":0}";
                        client->publish(ui->lineEdit_12->text(),msg);
                        ui->lineEdit_10->setText("超标");
                        beeper->setRate(1000);     //设置频率
                        beeper->start();
                        }
                    } else {
                        QByteArray msg="{\"smog\":false,\"id\":0}";
                        client->publish(ui->lineEdit_12->text(),msg);
                        ui->lineEdit_10->setText("未超标");
                        beeper->stop();
                    }
}






