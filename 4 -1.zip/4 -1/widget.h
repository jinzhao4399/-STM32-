#ifndef WIDGET_H
#define WIDGET_H
#include <QtMqtt/qmqttclient.h>
#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

//用户自定义槽函数声明
private slots:
    void on_pushButton_clicked();

private:
    Ui::Widget *ui;
    //创建mqtt客户端对象
    QMqttClient *client;
};
#endif // WIDGET_H
