#include "lianjie.h"
#include "ui_lianjie.h"

Lianjie::Lianjie(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Lianjie)
{
    ui->setupUi(this);
    QPixmap image;
    image.load(":/1.jpg");
    ui->label->setScaledContents(true);
    ui->label->setPixmap(image);
}

Lianjie::~Lianjie()
{
    delete ui;
}

void Lianjie::link(){
    QMqttTopicFilter topic=ui->lineEdit_3->text();
    client->subscribe(topic);
   // client->subscribe(ui->lineEdit_5->text());//主题
    connect(client,SIGNAL(messageReceived(QByteArray,QMqttTopicName)),this,SLOT(recv_data(QByteArray,QMqttTopicName)));
}






