#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QtMqtt/qmqttclient.h>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue> //json相关头文件
#include "fsmpLed.h"
#include "fsmpFan.h"
#include "fsmpBeeper.h"
#include "fsmpVibrator.h"
#include "fsmpLight.h"
#include "fsmpCamera.h"
#include "fsmpTempHum.h"

namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

private slots:

    void on_pushButton_clicked();
    void link();

    void recv_data(QByteArray,QMqttTopicName);    //订阅相关槽函数声明


    void on_pushButton_3_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_8_clicked();
    void on_pushButton_2_clicked();
    void show_pic(QImage);

    void on_pushButton_10_clicked();

    void on_pushButton_4_clicked();
    void updateTempHumValue();
    void updateLightValue();


private:
    Ui::Form *ui;
    QMqttClient *client;
    fsmpLeds *led1;
    fsmpFan *fan;
    fsmpBeeper *beeper;
    fsmpVibrator *vibrator;
    fsmpLight *light;
    QString m_publishTopic;
    QString m_subscribeTopic;
    fsmpCamera *v;
    fsmpTempHum *tem;
   QTimer *tempHumTimer;
   QTimer *lightTimer;



};

#endif // FORM_H
