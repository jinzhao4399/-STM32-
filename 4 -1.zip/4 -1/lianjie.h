#ifndef LIANJIE_H
#define LIANJIE_H

#include <QWidget>
#include <QtMqtt/qmqttclient.h> //添加mqtt客户端类相关头文件
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue> //json相关头文件

namespace Ui {
class Lianjie;
}

class Lianjie : public QWidget
{
    Q_OBJECT

public:
    explicit Lianjie(QWidget *parent = nullptr);
    ~Lianjie();

private slots:
    void link();

private:
    Ui::Lianjie *ui;
    QMqttClient *client;

};

#endif // LIANJIE_H
